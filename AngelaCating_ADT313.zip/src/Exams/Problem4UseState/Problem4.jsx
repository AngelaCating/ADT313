import { useState } from "react";
import { useRef } from "react";
import { useEffect } from "react";

export default function Problem4() {
  const [name, setName] = useState("");
  const [year, setYear] = useState("");
  const [course, setCourse] = useState("");
  const nameRef = useRef("");
  const yearRef = useRef("");
  const courseRef = useRef("");

  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type='text' ref = {nameRef} onChange={e => setName(e.target.value)}/>
      </div>
      <div style={{ display: 'block' }}>
        <p>Yearlevel:</p>
        <input type='radio' id='firstYear' name='yearlevel' value='Fist Year' 
          ref = {yearRef}
          onClick={e => setYear(e.target.value)}/>
          <label for='firstYear'>Fist Year</label>
        <br></br>
        <input
          type='radio'
          id='secondYear'
          name='yearlevel'
          value='Second Year'
          ref = {yearRef}
          onClick={e => setYear(e.target.value)}
        />
          <label for='secondYear'>Second Year</label>
        <br></br>
        <input
          type='radio'
          id='thirdYear'
          name='yearlevel'
          value='Third Year'
          ref = {yearRef}
          onClick={e => setYear(e.target.value)}
        />
          <label for='thirdYear'>Third Year</label>
        <br></br>
        <input
          type='radio'
          id='fourthYear'
          name='yearlevel'
          value='Fourth Year'
          ref = {yearRef}
          onClick={e => setYear(e.target.value)}
          />
          <label for='fourthYear'>Fourth Year</label>
        <br></br>
        <input
          type='radio'
          id='fifthYear'
          name='yearlevel'
          value='Fourth Year'
          ref = {yearRef}
          onClick={e => setYear(e.target.value)}
        />
          <label for='fifthYear'>Fifth Year</label>
        <br></br>
        <input type='radio' id='irregular' name='yearlevel' value='Irregular'
        ref = {yearRef}
        onClick={e => setYear(e.target.value)}/>
          <label for='irregular'>Irregular</label>
        <br></br>
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>

      <p>{name}</p>
      <p>{year}</p>
      <p>{course}</p>
    </>
  );
}
