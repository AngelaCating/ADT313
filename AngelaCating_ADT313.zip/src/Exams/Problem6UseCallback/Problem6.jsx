import { useCallback, useEffect, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selected, setSelected] = useState(null); 
  
  const handleEdit = useCallback((car) => {
    setSelected(car);
  }, [cars]); 

  
  const handleDelete = useCallback((car) => {
    setCars((prevCars) => prevCars.filter((c) => c !== car));
  }, [cars]); 
 
  const handleSave = () => {
    
    const newCar = {
     
    };

    setCars((prevCars) => [...prevCars, newCar]);
  };

  
  const handleUpdate = () => {
    if (!selected) return;
    const updatedCar = {
      ...selected,
      
    };

    setCars((prevCars) =>
      prevCars.map((car) => (car === selected ? updatedCar : car))
    );
  };

  
  const handleClear = () => {
    setSelected(null); 
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN: <input type='text' value={selected?.vin || ''} disabled />
        </div>
        <div style={{ display: 'block' }}>
          Make: <input type='text' value={selected?.make || ''} disabled />
        </div>
        <div style={{ display: 'block' }}>
          Model: <input type='text' value={selected?.model || ''} disabled />
        </div>
        <div style={{ display: 'block' }}>
          Year: <input type='text' value={selected?.year || ''} disabled />
        </div>
        <div style={{ display: 'block' }}>
          Color: <input type='text' value={selected?.color || ''} disabled />
        </div>
        <button type='button' onClick={handleSave} disabled={selected}>
          Save
        </button>
        <button type='button' onClick={handleUpdate} disabled={!selected}>
          Update
        </button>
        <button type='button' onClick={handleClear}>
          Clear
        </button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {cars.map((car, index) => (
              <tr key={car.vin}> {}
                <td>{car.vin}</td>
                <td>{car.make}</td>
                <td>{car.model}</td>
                <td>{car.year}</td>
                <td>{car.color}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(car)}>
                    Edit
                  </button>
                  <button type='button' onClick={() => handleDelete(car)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}